package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.*;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private CheckBox chk1, chk2, chk3;
    private static int SELECT_PICTURE = 150;
    private String fullName,postalAdress,email,telephoneNumber,sex,education,requirementsfromemployer,jobstatus;
    private RadioButton rb1,rb2;
    private ToggleButton tgb;
    private Switch s1,s2,s3,s4,s5;
    private TextView txtbox;
    private String date;
    private boolean czyPierwsze = true;
    private String agreement;
    private ImageView profilePicture;
    private Uri selectedImage;

    public void selectImageFromGallery(View view){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(Intent.createChooser(intent,"Select Image"),SELECT_PICTURE);
    }

public void onActivityResult(int requestCode,int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);

        if(resultCode == RESULT_OK){
            if(requestCode == SELECT_PICTURE){
                selectedImage = data.getData();
            }
            if(null != selectedImage){
                data.setData(selectedImage);
                ImageButton imgBtn = findViewById(R.id.imageButton);
                imgBtn.setImageURI(selectedImage);
            }
        }
}
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnClear = findViewById(R.id.buttonClear);

        profilePicture = findViewById(R.id.submittedProfilePicture);
        profilePicture.setVisibility(View.GONE);

        btnClear.setOnClickListener(v -> {



            fullName = String.valueOf(((EditText)findViewById(R.id.editTextText)).getText());
            date = String.valueOf(((EditText)findViewById(R.id.editTextDate)).getText());
            postalAdress = String.valueOf(((EditText)findViewById(R.id.editTextTextPostalAddress)).getText());
            email = String.valueOf(((EditText)findViewById(R.id.editTextTextEmailAddress)).getText());
            telephoneNumber = String.valueOf(((EditText)findViewById(R.id.editTextPhone)).getText());
            rb1 = findViewById(R.id.radioButton);
            rb2 = findViewById(R.id.radioButton2);
            sex = rb1.isChecked() ? rb1.getText().toString() : (rb2.isChecked() ? rb2.getText().toString() : "Nie wybrano");
            education = chk1.isChecked() ? chk1.getText().toString() : chk2.isChecked() ? chk2.getText().toString() : (chk3.isChecked() ? chk3.getText().toString() :"Nie wybrano");
            requirementsfromemployer = s1.isChecked() ? s1.getText().toString() : s2.isChecked() ? s2.getText().toString() : (s3.isChecked() ? s3.getText().toString() :"Nie wybrano");
            jobstatus = tgb.isChecked() ? tgb.getTextOn().toString() : tgb.getTextOff().toString();
            if (s5.isChecked()) agreement = "tak";
            else agreement = "nie";

            txtbox.setText("\n"+"                         Przesłano CV!" +
                    "\n" +
                    "\n Imię i nazwisko: " + fullName +
                    "\n Data urodzenia: " + date +
                    "\n Adres: " + postalAdress +
                    "\n Email: " + email +
                    "\n Telefon: " + telephoneNumber +
                    "\n Płeć: " + sex +
                    "\n Wykształcenie: " + education +
                    "\n Wymagania: " + requirementsfromemployer +
                    "\n Tryb pracy: " + jobstatus+
                    "\n" +
                    "\n Zgoda na przetwarzanie danych: " + agreement
                    );
            txtbox.setTextSize(20);
        });

        txtbox = findViewById(R.id.textView10);
        chk1 = findViewById(R.id.checkBox1);
        chk2 = findViewById(R.id.checkBox2);
        chk3 = findViewById(R.id.checkBox3);



        s1 = findViewById(R.id.switch1);
        s2 = findViewById(R.id.switch2);
        s3 = findViewById(R.id.switch3);

        s4 = findViewById(R.id.switch4);

        s5 = findViewById(R.id.switch5);

        tgb = findViewById(R.id.toggleButton2);

        chk1.setOnClickListener(this);
        chk2.setOnClickListener(this);
        chk3.setOnClickListener(this);

        s1.setOnClickListener(this);
        s2.setOnClickListener(this);
        s3.setOnClickListener(this);


        s4.setOnClickListener(this);

        s5.setOnClickListener(this);
        tgb.setOnClickListener(this);
    }

        @Override
    public void onClick(View view) {


        if(selectedImage != null){
            profilePicture.setImageURI(selectedImage);
        }
        else{
            profilePicture.setImageDrawable(getDrawable(R.drawable.blank));
        }

        profilePicture.setVisibility(View.VISIBLE);


            if (view.getId() == R.id.switch1) {
                s1.setChecked(true);
                s2.setChecked(false);
                s3.setChecked(false);
            } else if (view.getId() == R.id.switch2) {
                s2.setChecked(true);
                s1.setChecked(false);
                s3.setChecked(false);
            } else if (view.getId() == R.id.switch3) {
                s3.setChecked(true);
                s1.setChecked(false);
                s2.setChecked(false);
            }



        if (view.getId() == R.id.checkBox1) {
            chk1.setChecked(true);
            chk2.setChecked(false);
            chk3.setChecked(false);
        } else if (view.getId() == R.id.checkBox2) {
            chk2.setChecked(true);
            chk1.setChecked(false);
            chk3.setChecked(false);
        } else if (view.getId() == R.id.checkBox3) {
            chk3.setChecked(true);
            chk1.setChecked(false);
            chk2.setChecked(false);
        }


        if(((Switch)findViewById(R.id.switch4)).isChecked()){
            findViewById(R.id.editTextText).setEnabled(false);
            findViewById(R.id.editTextDate).setEnabled(false);
            findViewById(R.id.editTextTextPostalAddress).setEnabled(false);
            findViewById(R.id.editTextTextEmailAddress).setEnabled(false);
            findViewById(R.id.editTextPhone).setEnabled(false);
            findViewById(R.id.radioButton).setEnabled(false);
            findViewById(R.id.radioButton2).setEnabled(false);
            findViewById(R.id.checkBox1).setEnabled(false);
            findViewById(R.id.checkBox2).setEnabled(false);
            findViewById(R.id.checkBox3).setEnabled(false);
            findViewById(R.id.switch1).setEnabled(false);
            findViewById(R.id.switch2).setEnabled(false);
            findViewById(R.id.switch3).setEnabled(false);
            findViewById(R.id.switch5).setEnabled(false);
            findViewById(R.id.toggleButton2).setEnabled(false);
            findViewById(R.id.imageButton).setEnabled(false);

        }
        else{
            findViewById(R.id.editTextText).setEnabled(true);
            findViewById(R.id.editTextDate).setEnabled(true);
            findViewById(R.id.editTextTextPostalAddress).setEnabled(true);
            findViewById(R.id.editTextTextEmailAddress).setEnabled(true);
            findViewById(R.id.editTextPhone).setEnabled(true);
            findViewById(R.id.radioButton).setEnabled(true);
            findViewById(R.id.radioButton2).setEnabled(true);
            findViewById(R.id.checkBox1).setEnabled(true);
            findViewById(R.id.checkBox2).setEnabled(true);
            findViewById(R.id.checkBox3).setEnabled(true);
            findViewById(R.id.switch1).setEnabled(true);
            findViewById(R.id.switch2).setEnabled(true);
            findViewById(R.id.switch3).setEnabled(true);
            findViewById(R.id.switch5).setEnabled(true);
            findViewById(R.id.toggleButton2).setEnabled(true);
            findViewById(R.id.imageButton).setEnabled(true);
        }


    }
}
