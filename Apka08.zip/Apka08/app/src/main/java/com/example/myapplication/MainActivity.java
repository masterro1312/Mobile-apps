package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatActivity;
import android.view.ViewGroup;
import android.widget.*;
import android.widget.Toast;
import android.view.Gravity;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private CheckBox chk1, chk2, chk3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnClear = findViewById(R.id.buttonClear);

        btnClear.setOnClickListener(v -> {
            ViewGroup rootLayout = findViewById(R.id.main);
            clearAllViews(rootLayout);


            Toast toast = new Toast(getApplicationContext());
            TextView textView = new TextView(MainActivity.this);
            textView.setText("Przesłano CV!");
            textView.setTextColor(Color.WHITE);
            textView.setBackgroundColor(Color.parseColor("#CC000000"));
            textView.setPadding(40, 30, 40, 30);
            textView.setTextSize(16);
            textView.setGravity(Gravity.CENTER);
            toast.setView(textView);
            toast.setDuration(Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 200); // teraz na pewno będzie na górze
            toast.show();
        });

        chk1 = findViewById(R.id.checkBox1);
        chk2 = findViewById(R.id.checkBox2);
        chk3 = findViewById(R.id.checkBox3);


        chk1.setOnClickListener(this);
        chk2.setOnClickListener(this);
        chk3.setOnClickListener(this);
    }

    private void clearAllViews(ViewGroup parent) {
        for (int i = 0; i < parent.getChildCount(); i++) {
            View child = parent.getChildAt(i);
            if (child instanceof EditText) {
                ((EditText) child).setText("");
            } else if (child instanceof RadioGroup) {
                ((RadioGroup) child).clearCheck();
            } else if (child instanceof CheckBox) {
                ((CheckBox) child).setChecked(false);
            } else if (child instanceof Switch) {
                ((Switch) child).setChecked(false);
            } else if (child instanceof ToggleButton) {
                ((ToggleButton) child).setChecked(false);
            } else if (child instanceof ViewGroup) {
                clearAllViews((ViewGroup) child);
            }
        }
}

        @Override
    public void onClick(View view) {

        if (view.getId() == R.id.checkBox1) {
            chk1.setChecked(true);
            chk2.setChecked(false);
            chk3.setChecked(false);
        } else if (view.getId() == R.id.checkBox2) {
            chk2.setChecked(true);
            chk1.setChecked(false);
            chk3.setChecked(false);
        } else if (view.getId() == R.id.checkBox3) {
            chk3.setChecked(true);
            chk1.setChecked(false);
            chk2.setChecked(false);
        }
    }
}
